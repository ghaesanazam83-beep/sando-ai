import { useEffect, useRef, useState } from "react";
import {
  Check,
  Eye,
  EyeOff,
  KeyRound,
  PanelLeft,
  Plus,
  Send,
  Square,
  Trash2,
  X,
} from "lucide-react";
import { clsx } from "clsx";
import { apiPath } from "@/lib/sando/api-path";
import { DEFAULT_MODEL, MODELS, isModelId } from "@/lib/sando/models";
import { useSando, type ChatMessage } from "@/lib/sando/store";
import { MessageBody } from "@/components/sando/message-body";

const SUGGESTIONS = [
  "Rancang struktur modul untuk aplikasi catatan offline.",
  "Tulis fungsi TypeScript yang mem-parse log server, lengkap dengan edge case.",
  "Susun spesifikasi singkat API chat beserta validasi input.",
];

function titleFrom(text: string): string {
  const clean = text.replace(/\s+/g, " ").trim();
  return clean.length > 42 ? `${clean.slice(0, 42)}…` : clean;
}

export function SandoApp() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [narrow, setNarrow] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [armedDelete, setArmedDelete] = useState<string | null>(null);
  const [showKey, setShowKey] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const busyRef = useRef(false);
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const stickRef = useRef(true);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const threads = useSando((state) => state.threads);
  const activeId = useSando((state) => state.activeId);
  const apiKey = useSando((state) => state.apiKey);
  const model = useSando((state) => state.model);
  const setApiKey = useSando((state) => state.setApiKey);
  const setModel = useSando((state) => state.setModel);
  const newThread = useSando((state) => state.newThread);
  const selectThread = useSando((state) => state.selectThread);
  const deleteThread = useSando((state) => state.deleteThread);
  const ensureThread = useSando((state) => state.ensureThread);
  const appendMessages = useSando((state) => state.appendMessages);
  const patchMessage = useSando((state) => state.patchMessage);

  const active = threads.find((thread) => thread.id === activeId) ?? null;
  const knownModel = MODELS.some((item) => item.id === model);

  useEffect(() => {
    void useSando.persist.rehydrate();
  }, []);

  useEffect(() => {
    const media = window.matchMedia("(max-width: 767px)");
    const sync = () => setNarrow(media.matches);
    sync();
    media.addEventListener("change", sync);
    return () => media.removeEventListener("change", sync);
  }, []);

  useEffect(() => {
    if (!armedDelete) return;
    const timer = window.setTimeout(() => setArmedDelete(null), 2400);
    return () => window.clearTimeout(timer);
  }, [armedDelete]);

  const lastContent = active?.messages.at(-1)?.content ?? "";
  useEffect(() => {
    const node = scrollerRef.current;
    if (!node || !stickRef.current) return;
    node.scrollTop = node.scrollHeight;
  }, [lastContent, streaming, activeId]);

  function resizeComposer() {
    const node = textareaRef.current;
    if (!node) return;
    node.style.height = "0px";
    node.style.height = `${Math.min(node.scrollHeight, 160)}px`;
  }

  async function send(text: string) {
    const content = text.trim();
    if (!content || streaming || busyRef.current) return;
    if (apiKey.trim().length < 20) {
      setSettingsOpen(true);
      return;
    }
    const threadId = ensureThread();
    const existing = useSando.getState().threads.find((thread) => thread.id === threadId);
    const isFirst = !existing || existing.messages.length === 0;
    const userMessage: ChatMessage = { id: crypto.randomUUID(), role: "user", content };
    const assistantId = crypto.randomUUID();
    const assistant: ChatMessage = { id: assistantId, role: "assistant", content: "" };
    appendMessages(threadId, [userMessage, assistant], isFirst ? titleFrom(content) : undefined);
    setDraft("");
    if (textareaRef.current) textareaRef.current.style.height = "";
    busyRef.current = true;
    setStreaming(true);
    stickRef.current = true;

    const history = [...(existing?.messages ?? []), userMessage]
      .filter((message) => message.role === "user" || message.role === "assistant")
      .filter((message) => message.content.trim())
      .slice(-24)
      .map((message) => ({ role: message.role, content: message.content }));

    const controller = new AbortController();
    abortRef.current = controller;
    let buffer = "";
    let timer = 0;
    const flush = () => {
      timer = 0;
      patchMessage(threadId, assistantId, { content: buffer });
    };

    try {
      const response = await fetch(apiPath("/api/chat"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          apiKey: apiKey.trim(),
          model: isModelId(model) ? model : DEFAULT_MODEL,
          messages: history,
        }),
        signal: controller.signal,
      });
      if (!response.ok || !response.body) {
        const payload = (await response.json().catch(() => null)) as { error?: string } | null;
        throw new Error(payload?.error || "Permintaan gagal.");
      }
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        if (!timer) timer = window.setTimeout(flush, 48);
      }
      if (timer) window.clearTimeout(timer);
      const finalText = buffer.trim()
        ? buffer
        : "Model tidak mengembalikan teks. Coba Llama 3.3 70B.";
      patchMessage(threadId, assistantId, { content: finalText, failed: !buffer.trim() });
    } catch (error) {
      if (timer) window.clearTimeout(timer);
      if (error instanceof DOMException && error.name === "AbortError") {
        patchMessage(threadId, assistantId, {
          content: buffer.trim() ? buffer : "Dihentikan.",
        });
      } else {
        const message = error instanceof Error ? error.message : "Permintaan gagal.";
        patchMessage(threadId, assistantId, {
          content: buffer.trim() ? `${buffer}\n\n${message}` : message,
          failed: true,
        });
      }
    } finally {
      abortRef.current = null;
      busyRef.current = false;
      setStreaming(false);
    }
  }

  function stop() {
    abortRef.current?.abort();
  }

  async function copyMessage(message: ChatMessage) {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopiedId(message.id);
      window.setTimeout(() => setCopiedId((current) => (current === message.id ? null : current)), 1400);
    } catch {
      setCopiedId(null);
    }
  }

  return (
    <div className="flex h-dvh overflow-hidden bg-bg text-fg">
      {menuOpen ? (
        <button
          type="button"
          className="fixed inset-0 z-20 bg-bg/70 backdrop-blur-sm md:hidden"
          aria-label="Tutup menu"
          onClick={() => setMenuOpen(false)}
        />
      ) : null}

      <aside
        className={clsx("drawer flex-col border-r border-line bg-surface", menuOpen && "open")}
        inert={narrow && !menuOpen}
      >
        <div className="px-4 pt-5 pb-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="track font-mono text-xs text-muted">SANDO AI</p>
              <p className="mt-1 font-sans text-lg font-medium">Zamzzx</p>
            </div>
            <span className="live-dot size-2 rounded-full bg-accent" aria-hidden="true" />
          </div>
          <div className="mark-line mt-3 w-full" />
        </div>

        <div className="px-3">
          <button
            type="button"
            className="btn w-full"
            onClick={() => {
              newThread();
              setMenuOpen(false);
              textareaRef.current?.focus();
            }}
          >
            <Plus className="size-4" aria-hidden="true" />
            Percakapan baru
          </button>
        </div>

        <nav className="mt-3 flex-1 space-y-1 overflow-y-auto px-3 pb-3" aria-label="Riwayat">
          {threads.length === 0 ? (
            <p className="px-2 py-6 text-sm text-faint">Belum ada percakapan.</p>
          ) : (
            threads.map((thread) => {
              const selected = thread.id === activeId;
              return (
                <div key={thread.id} className="group flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => {
                      selectThread(thread.id);
                      setMenuOpen(false);
                    }}
                    className={clsx(
                      "btn h-auto min-h-11 flex-1 justify-start px-3 py-2 text-left",
                      selected && "border-accent/40 bg-fg/12",
                    )}
                  >
                    <span className="truncate text-sm">{thread.title}</span>
                  </button>
                  <button
                    type="button"
                    className="btn btn-icon shrink-0"
                    aria-label={armedDelete === thread.id ? "Konfirmasi hapus" : "Hapus percakapan"}
                    onClick={() => {
                      if (armedDelete === thread.id) {
                        deleteThread(thread.id);
                        setArmedDelete(null);
                      } else {
                        setArmedDelete(thread.id);
                      }
                    }}
                  >
                    <Trash2 className="size-4" aria-hidden="true" />
                  </button>
                </div>
              );
            })
          )}
        </nav>

        <div className="border-t border-line p-3">
          <button type="button" className="btn w-full justify-start" onClick={() => setSettingsOpen(true)}>
            <KeyRound className="size-4" aria-hidden="true" />
            <span className="truncate text-sm">
              {apiKey.trim().length >= 20 ? "Kunci tersimpan" : "Pasang kunci Groq"}
            </span>
          </button>
        </div>
      </aside>

      <main className="relative flex min-w-0 flex-1 flex-col">
        <div className="grid-wash pointer-events-none absolute inset-0" aria-hidden="true" />

        <header className="relative z-10 flex h-14 items-center gap-2 border-b border-line px-3 backdrop-blur-md">
          <button
            type="button"
            className="btn btn-icon md:hidden"
            aria-label="Buka menu"
            onClick={() => setMenuOpen(true)}
          >
            <PanelLeft className="size-4" aria-hidden="true" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm">{active?.title ?? "Sando AI"}</p>
            <p className="truncate font-mono text-xs text-faint">{model}</p>
          </div>
          <button type="button" className="btn" onClick={() => setSettingsOpen(true)}>
            Pengaturan
          </button>
        </header>

        <div
          ref={scrollerRef}
          className="relative z-10 flex-1 overflow-y-auto"
          onScroll={(event) => {
            const node = event.currentTarget;
            stickRef.current = node.scrollHeight - node.scrollTop - node.clientHeight < 80;
          }}
        >
          <div className="mx-auto flex min-h-full w-full max-w-3xl flex-col gap-6 px-4 py-6">
            {!active || active.messages.length === 0 ? (
              <EmptyState
                hasKey={apiKey.trim().length >= 20}
                onSuggest={(prompt) => void send(prompt)}
                onSettings={() => setSettingsOpen(true)}
              />
            ) : (
              active.messages.map((message) => (
                <article key={message.id} className="rise">
                  {message.role === "user" ? (
                    <div className="ml-auto max-w-xl rounded-card border border-line bg-fg/8 px-4 py-3 backdrop-blur-md">
                      <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                    </div>
                  ) : (
                    <div>
                      <div className="mb-2 flex items-center gap-2 font-mono text-xs text-muted">
                        <span className="size-1.5 rounded-full bg-accent" aria-hidden="true" />
                        ZAMZZX
                        {message.content ? (
                          <button
                            type="button"
                            className="btn ml-auto h-9 min-h-9 px-2 text-xs"
                            onClick={() => void copyMessage(message)}
                          >
                            {copiedId === message.id ? (
                              <Check className="size-3.5" aria-hidden="true" />
                            ) : null}
                            {copiedId === message.id ? "Tersalin" : "Salin"}
                          </button>
                        ) : null}
                      </div>
                      {message.content ? (
                        <div className={message.failed ? "text-muted" : undefined}>
                          <MessageBody text={message.content} />
                        </div>
                      ) : (
                        <p className="flex items-center gap-1 font-mono text-xs text-faint" aria-live="polite">
                          <span className="thinking-dot size-1.5 rounded-full bg-accent" />
                          <span className="thinking-dot size-1.5 rounded-full bg-accent" />
                          <span className="thinking-dot size-1.5 rounded-full bg-accent" />
                          <span className="sr-only">Menyusun jawaban</span>
                        </p>
                      )}
                    </div>
                  )}
                </article>
              ))
            )}
          </div>
        </div>

        <form
          className="relative z-10 border-t border-line bg-bg/75 p-3 backdrop-blur-md"
          onSubmit={(event) => {
            event.preventDefault();
            void send(draft);
          }}
        >
          <div className="mx-auto flex max-w-3xl items-end gap-2">
            <label className="sr-only" htmlFor="composer">
              Pesan
            </label>
            <textarea
              id="composer"
              ref={textareaRef}
              value={draft}
              rows={1}
              placeholder="Tulis tugas. Satu hal, lengkap."
              className="field max-h-40 min-h-12 flex-1 resize-none"
              onChange={(event) => {
                setDraft(event.target.value);
                resizeComposer();
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  void send(draft);
                }
              }}
            />
            {streaming ? (
              <button type="button" className="btn btn-icon" aria-label="Berhenti" onClick={stop}>
                <Square className="size-4" aria-hidden="true" />
              </button>
            ) : (
              <button type="submit" className="btn btn-accent btn-icon" aria-label="Kirim" disabled={!draft.trim()}>
                <Send className="size-4" aria-hidden="true" />
              </button>
            )}
          </div>
          <p className="mx-auto mt-2 max-w-3xl font-mono text-xs text-faint">
            Enter kirim · Shift+Enter baris baru
          </p>
        </form>
      </main>

      <div
        className={clsx(
          "fixed inset-0 z-40 flex items-end justify-center p-3 transition-opacity duration-200 sm:items-center",
          settingsOpen ? "opacity-100" : "pointer-events-none opacity-0",
        )}
        inert={!settingsOpen}
        aria-hidden={!settingsOpen}
      >
        <button
          type="button"
          className="absolute inset-0 bg-bg/70 backdrop-blur-sm"
          aria-label="Tutup pengaturan"
          onClick={() => setSettingsOpen(false)}
        />
        <section
          role="dialog"
          aria-modal="true"
          aria-labelledby="settings-title"
          className="rise relative z-10 w-full max-w-md rounded-card border border-line bg-elevated/90 p-5 backdrop-blur-md"
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="track font-mono text-xs text-muted">GROQ</p>
              <h2 id="settings-title" className="mt-1 text-lg font-medium">
                Pengaturan
              </h2>
            </div>
            <button type="button" className="btn btn-icon" aria-label="Tutup" onClick={() => setSettingsOpen(false)}>
              <X className="size-4" aria-hidden="true" />
            </button>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            Kunci hanya disimpan di peramban ini, lalu diteruskan ke Groq saat Anda mengirim pesan.
          </p>

          <label className="mt-5 block text-sm" htmlFor="groq-key">
            Kunci API
          </label>
          <div className="mt-2 flex gap-2">
            <input
              id="groq-key"
              className="field font-mono text-sm"
              type={showKey ? "text" : "password"}
              autoComplete="off"
              spellCheck={false}
              value={apiKey}
              placeholder="gsk_..."
              onChange={(event) => setApiKey(event.target.value)}
            />
            <button
              type="button"
              className="btn btn-icon"
              aria-label={showKey ? "Sembunyikan kunci" : "Tampilkan kunci"}
              onClick={() => setShowKey((value) => !value)}
            >
              {showKey ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
          {apiKey.trim() && !apiKey.trim().startsWith("gsk_") ? (
            <p className="mt-2 text-xs text-muted">Kunci Groq biasanya diawali gsk_.</p>
          ) : null}
          <a
            className="mt-2 inline-block text-sm underline decoration-line underline-offset-2"
            href="https://console.groq.com/keys"
            target="_blank"
            rel="noreferrer"
          >
            Ambil kunci di Groq Console
          </a>

          <label className="mt-5 block text-sm" htmlFor="model">
            Model
          </label>
          <select
            id="model"
            className="field mt-2"
            value={knownModel ? model : "custom"}
            onChange={(event) => {
              if (event.target.value !== "custom") setModel(event.target.value);
              else setModel("");
            }}
          >
            {MODELS.map((item) => (
              <option key={item.id} value={item.id}>
                {item.label} — {item.note}
              </option>
            ))}
            <option value="custom">ID model lain</option>
          </select>
          {!knownModel ? (
            <input
              className="field mt-2 font-mono text-sm"
              value={model}
              placeholder="misalnya llama-3.3-70b-versatile"
              onChange={(event) => setModel(event.target.value.trim())}
              aria-label="ID model kustom"
            />
          ) : null}

          <button type="button" className="btn btn-accent mt-5 w-full" onClick={() => setSettingsOpen(false)}>
            Selesai
          </button>
        </section>
      </div>
    </div>
  );
}

function EmptyState({
  hasKey,
  onSuggest,
  onSettings,
}: {
  hasKey: boolean;
  onSuggest: (prompt: string) => void;
  onSettings: () => void;
}) {
  return (
    <div className="flex flex-1 flex-col justify-center py-10">
      <p className="rise track font-mono text-xs text-muted">AGEN KODE & TULISAN</p>
      <h1 className="rise d1 mt-3 text-4xl font-medium tracking-tight">Sando AI</h1>
      <div className="rise d1 mark-line mt-4 w-24" />
      <p className="rise d2 mt-4 max-w-md text-sm leading-relaxed text-muted">
        Presisi dingin. Satu tugas, jawaban lengkap, format tetap. Identitas balasan: Zamzzx.
      </p>
      {hasKey ? (
        <div className="mt-6 flex flex-col items-start gap-2">
          {SUGGESTIONS.map((prompt, index) => (
            <button
              key={prompt}
              type="button"
              className={clsx(
                "btn rise h-auto min-h-11 max-w-lg justify-start px-4 py-3 text-left text-sm",
                index === 0 ? "d2" : index === 1 ? "d3" : "d4",
              )}
              onClick={() => onSuggest(prompt)}
            >
              {prompt}
            </button>
          ))}
        </div>
      ) : (
        <button type="button" className="btn btn-accent rise d3 mt-6" onClick={onSettings}>
          <KeyRound className="size-4" aria-hidden="true" />
          Pasang kunci Groq
        </button>
      )}
    </div>
  );
}
