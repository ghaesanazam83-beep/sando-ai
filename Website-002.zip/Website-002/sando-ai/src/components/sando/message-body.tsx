import type { ReactNode } from "react";

type Block =
  | { type: "text"; content: string }
  | { type: "code"; lang: string; content: string };

function splitFences(source: string): Block[] {
  const blocks: Block[] = [];
  const fence = /```([^\n`]*)\n?([\s\S]*?)```/g;
  let last = 0;
  let match: RegExpExecArray | null;
  while ((match = fence.exec(source))) {
    if (match.index > last) {
      blocks.push({ type: "text", content: source.slice(last, match.index) });
    }
    blocks.push({
      type: "code",
      lang: (match[1] ?? "").trim(),
      content: (match[2] ?? "").replace(/\n$/, ""),
    });
    last = match.index + match[0].length;
  }
  if (last < source.length) blocks.push({ type: "text", content: source.slice(last) });
  return blocks.length > 0 ? blocks : [{ type: "text", content: source }];
}

function Linkified({ text }: { text: string }) {
  const pattern = /https?:\/\/[^\s<>)\]]+/g;
  const nodes: ReactNode[] = [];
  let last = 0;
  let match: RegExpExecArray | null;
  let index = 0;
  while ((match = pattern.exec(text))) {
    const raw = match[0];
    if (match.index > last) nodes.push(text.slice(last, match.index));
    let href = raw;
    try {
      const url = new URL(raw);
      if (url.protocol === "http:" || url.protocol === "https:") href = url.toString();
      else href = "";
    } catch {
      href = "";
    }
    if (href) {
      nodes.push(
        <a
          key={`${href}-${index}`}
          href={href}
          target="_blank"
          rel="noreferrer"
          className="underline decoration-line underline-offset-2"
        >
          {raw}
        </a>,
      );
    } else {
      nodes.push(raw);
    }
    index += 1;
    last = match.index + raw.length;
  }
  if (last < text.length) nodes.push(text.slice(last));
  return <>{nodes}</>;
}

export function MessageBody({ text }: { text: string }) {
  const blocks = splitFences(text);
  return (
    <div className="space-y-3">
      {blocks.map((block, index) =>
        block.type === "code" ? (
          <pre
            key={index}
            className="overflow-x-auto rounded-card border border-line bg-bg px-3 py-3 font-mono text-xs leading-relaxed text-fg"
          >
            {block.lang ? (
              <div className="mb-2 font-mono text-xs text-faint">{block.lang}</div>
            ) : null}
            <code>{block.content}</code>
          </pre>
        ) : (
          <div key={index} className="font-mono text-sm leading-relaxed whitespace-pre-wrap text-fg">
            <Linkified text={block.content} />
          </div>
        ),
      )}
    </div>
  );
}
