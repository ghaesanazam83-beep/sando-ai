import { createFileRoute } from "@tanstack/react-router";
import { SandoApp } from "@/components/sando/sando-app";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <SandoApp />;
}
