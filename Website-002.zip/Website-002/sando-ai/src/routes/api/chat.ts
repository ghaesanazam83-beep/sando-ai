import { createFileRoute } from "@tanstack/react-router";
import { isModelId } from "@/lib/sando/models";
import { SANDO_SYSTEM_PROMPT } from "@/lib/sando/system-prompt";

const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
const MAX_MESSAGES = 24;
const MAX_CHARS = 12000;

type Incoming = {
  apiKey: string;
  model: string;
  messages: { role: "user" | "assistant"; content: string }[];
};

function redact(value: string): string {
  return value.replace(/gsk_[A-Za-z0-9_-]+/g, "gsk_redacted").slice(0, 500);
}

function parseBody(body: unknown): Incoming | { error: string } {
  if (!body || typeof body !== "object") return { error: "Body permintaan tidak valid." };
  const record = body as Record<string, unknown>;
  const apiKey = typeof record.apiKey === "string" ? record.apiKey.trim() : "";
  const model = typeof record.model === "string" ? record.model.trim() : "";
  if (apiKey.length < 20 || apiKey.length > 200) {
    return { error: "Kunci API Groq tidak valid." };
  }
  if (!isModelId(model)) return { error: "ID model tidak valid." };
  if (!Array.isArray(record.messages) || record.messages.length === 0) {
    return { error: "Pesan kosong." };
  }
  if (record.messages.length > MAX_MESSAGES) {
    return { error: "Riwayat terlalu panjang. Mulai percakapan baru." };
  }

  const messages: Incoming["messages"] = [];
  for (const item of record.messages) {
    if (!item || typeof item !== "object") return { error: "Format pesan tidak valid." };
    const row = item as Record<string, unknown>;
    if (row.role !== "user" && row.role !== "assistant") return { error: "Peran pesan tidak valid." };
    if (typeof row.content !== "string") return { error: "Isi pesan tidak valid." };
    const content = row.content.trim();
    if (!content) continue;
    if (content.length > MAX_CHARS) return { error: "Satu pesan melebihi batas panjang." };
    const previous = messages[messages.length - 1];
    if (previous && previous.role === row.role) {
      previous.content = `${previous.content}\n\n${content}`;
    } else {
      messages.push({ role: row.role, content });
    }
  }

  if (messages.length === 0 || messages[0]?.role !== "user") {
    return { error: "Percakapan harus dimulai dari pesan Anda." };
  }
  if (messages[messages.length - 1]?.role !== "user") {
    return { error: "Pesan terakhir harus dari Anda." };
  }

  return { apiKey, model, messages };
}

function groqMessage(status: number, raw: string): string {
  if (status === 401 || status === 403) {
    return "Kunci API Groq ditolak. Periksa kunci di pengaturan.";
  }
  if (status === 429) return "Batas permintaan Groq tercapai. Tunggu sebentar, lalu coba lagi.";
  try {
    const parsed = JSON.parse(raw) as { error?: { message?: string } | string };
    const message = typeof parsed.error === "string" ? parsed.error : parsed.error?.message;
    if (message) return redact(message);
  } catch {
    /* Groq sometimes returns plain text. */
  }
  return `Groq menolak permintaan (${status}).`;
}

function extractDelta(payload: unknown): string {
  if (!payload || typeof payload !== "object") return "";
  const choices = (payload as { choices?: unknown }).choices;
  if (!Array.isArray(choices) || !choices[0] || typeof choices[0] !== "object") return "";
  const delta = (choices[0] as { delta?: { content?: unknown } }).delta;
  return typeof delta?.content === "string" ? delta.content : "";
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let parsed: Incoming | { error: string };
        try {
          parsed = parseBody(await request.json());
        } catch {
          return Response.json({ error: "JSON tidak valid." }, { status: 400 });
        }
        if ("error" in parsed) {
          return Response.json({ error: parsed.error }, { status: 400 });
        }

        let upstream: Response;
        try {
          upstream = await fetch(GROQ_URL, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${parsed.apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: parsed.model,
              temperature: 0.4,
              max_tokens: 4096,
              stream: true,
              messages: [{ role: "system", content: SANDO_SYSTEM_PROMPT }, ...parsed.messages],
            }),
          });
        } catch {
          return Response.json(
            { error: "Tidak terhubung ke Groq. Periksa jaringan, lalu coba lagi." },
            { status: 502 },
          );
        }

        if (!upstream.ok || !upstream.body) {
          const raw = await upstream.text().catch(() => "");
          return Response.json(
            { error: groqMessage(upstream.status, raw) },
            { status: upstream.status || 502 },
          );
        }

        const decoder = new TextDecoder();
        const encoder = new TextEncoder();
        const reader = upstream.body.getReader();
        let buffer = "";

        const stream = new ReadableStream<Uint8Array>({
          async pull(controller) {
            try {
              const { done, value } = await reader.read();
              if (done) {
                controller.close();
                return;
              }
              buffer += decoder.decode(value, { stream: true });
              const lines = buffer.split("\n");
              buffer = lines.pop() ?? "";
              let piece = "";
              for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed.startsWith("data:")) continue;
                const data = trimmed.slice(5).trim();
                if (!data || data === "[DONE]") continue;
                try {
                  piece += extractDelta(JSON.parse(data));
                } catch {
                  /* ignore a partial keepalive frame */
                }
              }
              if (piece) controller.enqueue(encoder.encode(piece));
            } catch {
              controller.error(new Error("Aliran jawaban terputus."));
            }
          },
          cancel() {
            void reader.cancel();
          },
        });

        return new Response(stream, {
          headers: {
            "Content-Type": "text/plain; charset=utf-8",
            "Cache-Control": "no-store",
          },
        });
      },
    },
  },
});
