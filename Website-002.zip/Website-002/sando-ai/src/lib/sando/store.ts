import { create } from "zustand";
import { persist } from "zustand/middleware";
import { DEFAULT_MODEL } from "@/lib/sando/models";

export type Role = "user" | "assistant";

export type ChatMessage = {
  id: string;
  role: Role;
  content: string;
  failed?: boolean;
};

export type Thread = {
  id: string;
  title: string;
  messages: ChatMessage[];
  updatedAt: number;
};

type SandoState = {
  threads: Thread[];
  activeId: string | null;
  apiKey: string;
  model: string;
  setApiKey: (apiKey: string) => void;
  setModel: (model: string) => void;
  newThread: () => string;
  selectThread: (id: string) => void;
  deleteThread: (id: string) => void;
  ensureThread: () => string;
  appendMessages: (threadId: string, messages: ChatMessage[], title?: string) => void;
  patchMessage: (threadId: string, messageId: string, patch: Partial<ChatMessage>) => void;
};

export const useSando = create<SandoState>()(
  persist(
    (set, get) => ({
      threads: [],
      activeId: null,
      apiKey: "",
      model: DEFAULT_MODEL,
      setApiKey: (apiKey) => set({ apiKey }),
      setModel: (model) => set({ model }),
      newThread: () => {
        const id = crypto.randomUUID();
        const thread: Thread = {
          id,
          title: "Percakapan baru",
          messages: [],
          updatedAt: Date.now(),
        };
        set((state) => ({ threads: [thread, ...state.threads], activeId: id }));
        return id;
      },
      selectThread: (id) => set({ activeId: id }),
      deleteThread: (id) =>
        set((state) => {
          const threads = state.threads.filter((thread) => thread.id !== id);
          const activeId = state.activeId === id ? (threads[0]?.id ?? null) : state.activeId;
          return { threads, activeId };
        }),
      ensureThread: () => {
        const { activeId, threads } = get();
        if (activeId && threads.some((thread) => thread.id === activeId)) return activeId;
        return get().newThread();
      },
      appendMessages: (threadId, messages, title) =>
        set((state) => ({
          threads: state.threads.map((thread) =>
            thread.id === threadId
              ? {
                  ...thread,
                  title: title ?? thread.title,
                  messages: [...thread.messages, ...messages],
                  updatedAt: Date.now(),
                }
              : thread,
          ),
        })),
      patchMessage: (threadId, messageId, patch) =>
        set((state) => ({
          threads: state.threads.map((thread) =>
            thread.id !== threadId
              ? thread
              : {
                  ...thread,
                  updatedAt: Date.now(),
                  messages: thread.messages.map((message) =>
                    message.id === messageId ? { ...message, ...patch } : message,
                  ),
                },
          ),
        })),
    }),
    {
      name: "sando-ai",
      skipHydration: true,
      partialize: (state) => ({
        apiKey: state.apiKey,
        model: state.model,
        activeId: state.activeId,
        threads: state.threads.slice(0, 30).map((thread) => ({
          ...thread,
          messages: thread.messages.slice(-80).map((message) => ({
            id: message.id,
            role: message.role,
            content: message.content.slice(0, 20000),
            failed: message.failed,
          })),
        })),
      }),
    },
  ),
);
