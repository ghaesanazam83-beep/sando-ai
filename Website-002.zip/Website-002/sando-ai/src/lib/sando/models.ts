export const MODELS = [
  { id: "llama-3.3-70b-versatile", label: "Llama 3.3 70B", note: "Disarankan" },
  { id: "llama-3.1-8b-instant", label: "Llama 3.1 8B", note: "Cepat" },
  { id: "openai/gpt-oss-120b", label: "GPT-OSS 120B", note: "Kuat" },
  { id: "openai/gpt-oss-20b", label: "GPT-OSS 20B", note: "Ringan" },
] as const;

export const DEFAULT_MODEL = MODELS[0].id;

const MODEL_PATTERN = /^[a-zA-Z0-9._:/-]{2,96}$/;

export function isModelId(value: string): boolean {
  return MODEL_PATTERN.test(value);
}
