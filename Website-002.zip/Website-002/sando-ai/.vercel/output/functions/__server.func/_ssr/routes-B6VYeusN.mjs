import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Send, c as KeyRound, d as Check, i as Square, l as Eye, o as Plus, r as Trash2, s as PanelLeft, t as X, u as EyeOff } from "../_libs/lucide-react.mjs";
import { a as previewPathPrefix, i as isModelId, n as DEFAULT_MODEL, r as MODELS } from "./router-C_nVLGij.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B6VYeusN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function apiPath(path) {
	if (typeof window === "undefined") return path;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? `${prefix}${path}` : path;
}
var useSando = create()(persist((set, get) => ({
	threads: [],
	activeId: null,
	apiKey: "",
	model: DEFAULT_MODEL,
	setApiKey: (apiKey) => set({ apiKey }),
	setModel: (model) => set({ model }),
	newThread: () => {
		const id = crypto.randomUUID();
		const thread = {
			id,
			title: "Percakapan baru",
			messages: [],
			updatedAt: Date.now()
		};
		set((state) => ({
			threads: [thread, ...state.threads],
			activeId: id
		}));
		return id;
	},
	selectThread: (id) => set({ activeId: id }),
	deleteThread: (id) => set((state) => {
		const threads = state.threads.filter((thread) => thread.id !== id);
		return {
			threads,
			activeId: state.activeId === id ? threads[0]?.id ?? null : state.activeId
		};
	}),
	ensureThread: () => {
		const { activeId, threads } = get();
		if (activeId && threads.some((thread) => thread.id === activeId)) return activeId;
		return get().newThread();
	},
	appendMessages: (threadId, messages, title) => set((state) => ({ threads: state.threads.map((thread) => thread.id === threadId ? {
		...thread,
		title: title ?? thread.title,
		messages: [...thread.messages, ...messages],
		updatedAt: Date.now()
	} : thread) })),
	patchMessage: (threadId, messageId, patch) => set((state) => ({ threads: state.threads.map((thread) => thread.id !== threadId ? thread : {
		...thread,
		updatedAt: Date.now(),
		messages: thread.messages.map((message) => message.id === messageId ? {
			...message,
			...patch
		} : message)
	}) }))
}), {
	name: "sando-ai",
	skipHydration: true,
	partialize: (state) => ({
		apiKey: state.apiKey,
		model: state.model,
		activeId: state.activeId,
		threads: state.threads.slice(0, 30).map((thread) => ({
			...thread,
			messages: thread.messages.slice(-80).map((message) => ({
				id: message.id,
				role: message.role,
				content: message.content.slice(0, 2e4),
				failed: message.failed
			}))
		}))
	})
}));
function splitFences(source) {
	const blocks = [];
	const fence = /```([^\n`]*)\n?([\s\S]*?)```/g;
	let last = 0;
	let match;
	while (match = fence.exec(source)) {
		if (match.index > last) blocks.push({
			type: "text",
			content: source.slice(last, match.index)
		});
		blocks.push({
			type: "code",
			lang: (match[1] ?? "").trim(),
			content: (match[2] ?? "").replace(/\n$/, "")
		});
		last = match.index + match[0].length;
	}
	if (last < source.length) blocks.push({
		type: "text",
		content: source.slice(last)
	});
	return blocks.length > 0 ? blocks : [{
		type: "text",
		content: source
	}];
}
function Linkified({ text }) {
	const pattern = /https?:\/\/[^\s<>)\]]+/g;
	const nodes = [];
	let last = 0;
	let match;
	let index = 0;
	while (match = pattern.exec(text)) {
		const raw = match[0];
		if (match.index > last) nodes.push(text.slice(last, match.index));
		let href = raw;
		try {
			const url = new URL(raw);
			if (url.protocol === "http:" || url.protocol === "https:") href = url.toString();
			else href = "";
		} catch {
			href = "";
		}
		if (href) nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href,
			target: "_blank",
			rel: "noreferrer",
			className: "underline decoration-line underline-offset-2",
			children: raw
		}, `${href}-${index}`));
		else nodes.push(raw);
		index += 1;
		last = match.index + raw.length;
	}
	if (last < text.length) nodes.push(text.slice(last));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: nodes });
}
function MessageBody({ text }) {
	const blocks = splitFences(text);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: blocks.map((block, index) => block.type === "code" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("pre", {
			className: "overflow-x-auto rounded-card border border-line bg-bg px-3 py-3 font-mono text-xs leading-relaxed text-fg",
			children: [block.lang ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 font-mono text-xs text-faint",
				children: block.lang
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: block.content })]
		}, index) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-mono text-sm leading-relaxed whitespace-pre-wrap text-fg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkified, { text: block.content })
		}, index))
	});
}
var SUGGESTIONS = [
	"Rancang struktur modul untuk aplikasi catatan offline.",
	"Tulis fungsi TypeScript yang mem-parse log server, lengkap dengan edge case.",
	"Susun spesifikasi singkat API chat beserta validasi input."
];
function titleFrom(text) {
	const clean = text.replace(/\s+/g, " ").trim();
	return clean.length > 42 ? `${clean.slice(0, 42)}…` : clean;
}
function SandoApp() {
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [narrow, setNarrow] = (0, import_react.useState)(false);
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [streaming, setStreaming] = (0, import_react.useState)(false);
	const [copiedId, setCopiedId] = (0, import_react.useState)(null);
	const [armedDelete, setArmedDelete] = (0, import_react.useState)(null);
	const [showKey, setShowKey] = (0, import_react.useState)(false);
	const abortRef = (0, import_react.useRef)(null);
	const busyRef = (0, import_react.useRef)(false);
	const scrollerRef = (0, import_react.useRef)(null);
	const stickRef = (0, import_react.useRef)(true);
	const textareaRef = (0, import_react.useRef)(null);
	const threads = useSando((state) => state.threads);
	const activeId = useSando((state) => state.activeId);
	const apiKey = useSando((state) => state.apiKey);
	const model = useSando((state) => state.model);
	const setApiKey = useSando((state) => state.setApiKey);
	const setModel = useSando((state) => state.setModel);
	const newThread = useSando((state) => state.newThread);
	const selectThread = useSando((state) => state.selectThread);
	const deleteThread = useSando((state) => state.deleteThread);
	const ensureThread = useSando((state) => state.ensureThread);
	const appendMessages = useSando((state) => state.appendMessages);
	const patchMessage = useSando((state) => state.patchMessage);
	const active = threads.find((thread) => thread.id === activeId) ?? null;
	const knownModel = MODELS.some((item) => item.id === model);
	(0, import_react.useEffect)(() => {
		useSando.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		const media = window.matchMedia("(max-width: 767px)");
		const sync = () => setNarrow(media.matches);
		sync();
		media.addEventListener("change", sync);
		return () => media.removeEventListener("change", sync);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!armedDelete) return;
		const timer = window.setTimeout(() => setArmedDelete(null), 2400);
		return () => window.clearTimeout(timer);
	}, [armedDelete]);
	const lastContent = active?.messages.at(-1)?.content ?? "";
	(0, import_react.useEffect)(() => {
		const node = scrollerRef.current;
		if (!node || !stickRef.current) return;
		node.scrollTop = node.scrollHeight;
	}, [
		lastContent,
		streaming,
		activeId
	]);
	function resizeComposer() {
		const node = textareaRef.current;
		if (!node) return;
		node.style.height = "0px";
		node.style.height = `${Math.min(node.scrollHeight, 160)}px`;
	}
	async function send(text) {
		const content = text.trim();
		if (!content || streaming || busyRef.current) return;
		if (apiKey.trim().length < 20) {
			setSettingsOpen(true);
			return;
		}
		const threadId = ensureThread();
		const existing = useSando.getState().threads.find((thread) => thread.id === threadId);
		const isFirst = !existing || existing.messages.length === 0;
		const userMessage = {
			id: crypto.randomUUID(),
			role: "user",
			content
		};
		const assistantId = crypto.randomUUID();
		appendMessages(threadId, [userMessage, {
			id: assistantId,
			role: "assistant",
			content: ""
		}], isFirst ? titleFrom(content) : void 0);
		setDraft("");
		if (textareaRef.current) textareaRef.current.style.height = "";
		busyRef.current = true;
		setStreaming(true);
		stickRef.current = true;
		const history = [...existing?.messages ?? [], userMessage].filter((message) => message.role === "user" || message.role === "assistant").filter((message) => message.content.trim()).slice(-24).map((message) => ({
			role: message.role,
			content: message.content
		}));
		const controller = new AbortController();
		abortRef.current = controller;
		let buffer = "";
		let timer = 0;
		const flush = () => {
			timer = 0;
			patchMessage(threadId, assistantId, { content: buffer });
		};
		try {
			const response = await fetch(apiPath("/api/chat"), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					apiKey: apiKey.trim(),
					model: isModelId(model) ? model : DEFAULT_MODEL,
					messages: history
				}),
				signal: controller.signal
			});
			if (!response.ok || !response.body) {
				const payload = await response.json().catch(() => null);
				throw new Error(payload?.error || "Permintaan gagal.");
			}
			const reader = response.body.getReader();
			const decoder = new TextDecoder();
			while (true) {
				const { done, value } = await reader.read();
				if (done) break;
				buffer += decoder.decode(value, { stream: true });
				if (!timer) timer = window.setTimeout(flush, 48);
			}
			if (timer) window.clearTimeout(timer);
			const finalText = buffer.trim() ? buffer : "Model tidak mengembalikan teks. Coba Llama 3.3 70B.";
			patchMessage(threadId, assistantId, {
				content: finalText,
				failed: !buffer.trim()
			});
		} catch (error) {
			if (timer) window.clearTimeout(timer);
			if (error instanceof DOMException && error.name === "AbortError") patchMessage(threadId, assistantId, { content: buffer.trim() ? buffer : "Dihentikan." });
			else {
				const message = error instanceof Error ? error.message : "Permintaan gagal.";
				patchMessage(threadId, assistantId, {
					content: buffer.trim() ? `${buffer}\n\n${message}` : message,
					failed: true
				});
			}
		} finally {
			abortRef.current = null;
			busyRef.current = false;
			setStreaming(false);
		}
	}
	function stop() {
		abortRef.current?.abort();
	}
	async function copyMessage(message) {
		try {
			await navigator.clipboard.writeText(message.content);
			setCopiedId(message.id);
			window.setTimeout(() => setCopiedId((current) => current === message.id ? null : current), 1400);
		} catch {
			setCopiedId(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh overflow-hidden bg-bg text-fg",
		children: [
			menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "fixed inset-0 z-20 bg-bg/70 backdrop-blur-sm md:hidden",
				"aria-label": "Tutup menu",
				onClick: () => setMenuOpen(false)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: clsx("drawer flex-col border-r border-line bg-surface", menuOpen && "open"),
				inert: narrow && !menuOpen,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 pt-5 pb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "track font-mono text-xs text-muted",
								children: "SANDO AI"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-sans text-lg font-medium",
								children: "Zamzzx"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "live-dot size-2 rounded-full bg-accent",
								"aria-hidden": "true"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mark-line mt-3 w-full" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn w-full",
							onClick: () => {
								newThread();
								setMenuOpen(false);
								textareaRef.current?.focus();
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Percakapan baru"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-3 flex-1 space-y-1 overflow-y-auto px-3 pb-3",
						"aria-label": "Riwayat",
						children: threads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-2 py-6 text-sm text-faint",
							children: "Belum ada percakapan."
						}) : threads.map((thread) => {
							const selected = thread.id === activeId;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										selectThread(thread.id);
										setMenuOpen(false);
									},
									className: clsx("btn h-auto min-h-11 flex-1 justify-start px-3 py-2 text-left", selected && "border-accent/40 bg-fg/12"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate text-sm",
										children: thread.title
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-icon shrink-0",
									"aria-label": armedDelete === thread.id ? "Konfirmasi hapus" : "Hapus percakapan",
									onClick: () => {
										if (armedDelete === thread.id) {
											deleteThread(thread.id);
											setArmedDelete(null);
										} else setArmedDelete(thread.id);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
										className: "size-4",
										"aria-hidden": "true"
									})
								})]
							}, thread.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t border-line p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn w-full justify-start",
							onClick: () => setSettingsOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
								className: "size-4",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-sm",
								children: apiKey.trim().length >= 20 ? "Kunci tersimpan" : "Pasang kunci Groq"
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid-wash pointer-events-none absolute inset-0",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "relative z-10 flex h-14 items-center gap-2 border-b border-line px-3 backdrop-blur-md",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-icon md:hidden",
								"aria-label": "Buka menu",
								onClick: () => setMenuOpen(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeft, {
									className: "size-4",
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm",
									children: active?.title ?? "Sando AI"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-mono text-xs text-faint",
									children: model
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn",
								onClick: () => setSettingsOpen(true),
								children: "Pengaturan"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: scrollerRef,
						className: "relative z-10 flex-1 overflow-y-auto",
						onScroll: (event) => {
							const node = event.currentTarget;
							stickRef.current = node.scrollHeight - node.scrollTop - node.clientHeight < 80;
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto flex min-h-full w-full max-w-3xl flex-col gap-6 px-4 py-6",
							children: !active || active.messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
								hasKey: apiKey.trim().length >= 20,
								onSuggest: (prompt) => void send(prompt),
								onSettings: () => setSettingsOpen(true)
							}) : active.messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
								className: "rise",
								children: message.role === "user" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "ml-auto max-w-xl rounded-card border border-line bg-fg/8 px-4 py-3 backdrop-blur-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm leading-relaxed whitespace-pre-wrap",
										children: message.content
									})
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2 flex items-center gap-2 font-mono text-xs text-muted",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-1.5 rounded-full bg-accent",
											"aria-hidden": "true"
										}),
										"ZAMZZX",
										message.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "btn ml-auto h-9 min-h-9 px-2 text-xs",
											onClick: () => void copyMessage(message),
											children: [copiedId === message.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
												className: "size-3.5",
												"aria-hidden": "true"
											}) : null, copiedId === message.id ? "Tersalin" : "Salin"]
										}) : null
									]
								}), message.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: message.failed ? "text-muted" : void 0,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageBody, { text: message.content })
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-1 font-mono text-xs text-faint",
									"aria-live": "polite",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "thinking-dot size-1.5 rounded-full bg-accent" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "thinking-dot size-1.5 rounded-full bg-accent" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "thinking-dot size-1.5 rounded-full bg-accent" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sr-only",
											children: "Menyusun jawaban"
										})
									]
								})] })
							}, message.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "relative z-10 border-t border-line bg-bg/75 p-3 backdrop-blur-md",
						onSubmit: (event) => {
							event.preventDefault();
							send(draft);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex max-w-3xl items-end gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "sr-only",
									htmlFor: "composer",
									children: "Pesan"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "composer",
									ref: textareaRef,
									value: draft,
									rows: 1,
									placeholder: "Tulis tugas. Satu hal, lengkap.",
									className: "field max-h-40 min-h-12 flex-1 resize-none",
									onChange: (event) => {
										setDraft(event.target.value);
										resizeComposer();
									},
									onKeyDown: (event) => {
										if (event.key === "Enter" && !event.shiftKey) {
											event.preventDefault();
											send(draft);
										}
									}
								}),
								streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-icon",
									"aria-label": "Berhenti",
									onClick: stop,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {
										className: "size-4",
										"aria-hidden": "true"
									})
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "btn btn-accent btn-icon",
									"aria-label": "Kirim",
									disabled: !draft.trim(),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
										className: "size-4",
										"aria-hidden": "true"
									})
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-2 max-w-3xl font-mono text-xs text-faint",
							children: "Enter kirim · Shift+Enter baris baru"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: clsx("fixed inset-0 z-40 flex items-end justify-center p-3 transition-opacity duration-200 sm:items-center", settingsOpen ? "opacity-100" : "pointer-events-none opacity-0"),
				inert: !settingsOpen,
				"aria-hidden": !settingsOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute inset-0 bg-bg/70 backdrop-blur-sm",
					"aria-label": "Tutup pengaturan",
					onClick: () => setSettingsOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "settings-title",
					className: "rise relative z-10 w-full max-w-md rounded-card border border-line bg-elevated/90 p-5 backdrop-blur-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "track font-mono text-xs text-muted",
								children: "GROQ"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "settings-title",
								className: "mt-1 text-lg font-medium",
								children: "Pengaturan"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-icon",
								"aria-label": "Tutup",
								onClick: () => setSettingsOpen(false),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
									className: "size-4",
									"aria-hidden": "true"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: "Kunci hanya disimpan di peramban ini, lalu diteruskan ke Groq saat Anda mengirim pesan."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-5 block text-sm",
							htmlFor: "groq-key",
							children: "Kunci API"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "groq-key",
								className: "field font-mono text-sm",
								type: showKey ? "text" : "password",
								autoComplete: "off",
								spellCheck: false,
								value: apiKey,
								placeholder: "gsk_...",
								onChange: (event) => setApiKey(event.target.value)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-icon",
								"aria-label": showKey ? "Sembunyikan kunci" : "Tampilkan kunci",
								onClick: () => setShowKey((value) => !value),
								children: showKey ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
							})]
						}),
						apiKey.trim() && !apiKey.trim().startsWith("gsk_") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: "Kunci Groq biasanya diawali gsk_."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "mt-2 inline-block text-sm underline decoration-line underline-offset-2",
							href: "https://console.groq.com/keys",
							target: "_blank",
							rel: "noreferrer",
							children: "Ambil kunci di Groq Console"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-5 block text-sm",
							htmlFor: "model",
							children: "Model"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "model",
							className: "field mt-2",
							value: knownModel ? model : "custom",
							onChange: (event) => {
								if (event.target.value !== "custom") setModel(event.target.value);
								else setModel("");
							},
							children: [MODELS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: item.id,
								children: [
									item.label,
									" — ",
									item.note
								]
							}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "custom",
								children: "ID model lain"
							})]
						}),
						!knownModel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-2 font-mono text-sm",
							value: model,
							placeholder: "misalnya llama-3.3-70b-versatile",
							onChange: (event) => setModel(event.target.value.trim()),
							"aria-label": "ID model kustom"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-accent mt-5 w-full",
							onClick: () => setSettingsOpen(false),
							children: "Selesai"
						})
					]
				})]
			})
		]
	});
}
function EmptyState({ hasKey, onSuggest, onSettings }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col justify-center py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rise track font-mono text-xs text-muted",
				children: "AGEN KODE & TULISAN"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "rise d1 mt-3 text-4xl font-medium tracking-tight",
				children: "Sando AI"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rise d1 mark-line mt-4 w-24" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rise d2 mt-4 max-w-md text-sm leading-relaxed text-muted",
				children: "Presisi dingin. Satu tugas, jawaban lengkap, format tetap. Identitas balasan: Zamzzx."
			}),
			hasKey ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex flex-col items-start gap-2",
				children: SUGGESTIONS.map((prompt, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: clsx("btn rise h-auto min-h-11 max-w-lg justify-start px-4 py-3 text-left text-sm", index === 0 ? "d2" : index === 1 ? "d3" : "d4"),
					onClick: () => onSuggest(prompt),
					children: prompt
				}, prompt))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "btn btn-accent rise d3 mt-6",
				onClick: onSettings,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
					className: "size-4",
					"aria-hidden": "true"
				}), "Pasang kunci Groq"]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SandoApp, {});
}
//#endregion
export { Home as component };
